# ⚠️ DISCLAIMER - READ BEFORE USE

## 🚨 CRITICAL WARNING

**THIS IS A PENETRATION TESTING TOOLKIT DESIGNED FOR AUTHORIZED SECURITY TESTING ONLY**

---

## ❌ UNAUTHORIZED USE IS ILLEGAL

Using this software to scan, probe, or attack networks, systems, or services that you do not own or have explicit written permission to test is **ILLEGAL** and may result in:

- **Criminal charges** and prosecution under computer crime laws
- **Substantial fines** (potentially millions of dollars)
- **Prison time** (multiple years depending on jurisdiction and severity)
- **Permanent criminal record** affecting future employment and travel
- **Civil lawsuits** for damages and business disruption

---

## ✅ AUTHORIZED USE ONLY

This toolkit should **ONLY** be used:

- On your own networks and systems
- With explicit written authorization from system owners
- Within the scope of authorized penetration testing contracts
- As part of legitimate bug bounty programs
- In controlled educational environments

---

## 🚫 COMPLETE DISCLAIMER OF LIABILITY

**ООО "ИЗИПРОТЕК" AND THE SOFTWARE AUTHORS:**

- Provide this software "AS IS" with **NO WARRANTY** of any kind
- Are **NOT RESPONSIBLE** for any damage, harm, or legal consequences from your use
- Will **NOT PROVIDE SUPPORT** for illegal or unauthorized activities
- **EXPRESSLY DISCLAIM** all liability for misuse of this software

**YOU USE THIS SOFTWARE AT YOUR OWN RISK AND ACCEPT FULL RESPONSIBILITY FOR YOUR ACTIONS.**

---

## 📋 YOUR RESPONSIBILITIES

By using this software, you agree to:

1. **Comply with all applicable laws** in your jurisdiction
2. **Obtain proper authorization** before testing any systems
3. **Use the software ethically** and responsibly
4. **Accept full liability** for your actions and their consequences
5. **Indemnify and hold harmless** EasyProTech LLC from any claims

---

## 🆘 WHEN IN DOUBT, DON'T USE IT

If you are unsure whether your intended use is legal or authorized, **DO NOT USE THIS SOFTWARE**. Consult with:

- Legal counsel familiar with cybersecurity law
- Your organization's compliance team
- The system owners for explicit written permission
- ООО "ИЗИПРОТЕК" via @easyprotechaifactory (for licensing questions only)

---

**REMEMBER: The goal is to improve security, not cause harm. Use responsibly.**

---

*For full legal terms, see LEGAL.md*
*For ethical guidelines, see ETHICS.md*

**ООО "ИЗИПРОТЕК" | Brabus Recon Suite v1.0 | @easyprotechaifactory** 